﻿Public Class About
    Private Sub okbtn_Click(sender As Object, e As EventArgs) Handles okbtn.Click
        Me.Close()
    End Sub

End Class